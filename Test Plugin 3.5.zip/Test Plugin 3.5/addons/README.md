# How to use

To use these plugins in another project, copy any of these
folders to the `addons/` folder in a Godot project.

For example, the path would look like: `addons/custom_node`

Plugins can be distributed and installed from the UI.
If you make a zip that contains the folder, Godot will recognize
it as a plugin and will allow you to install it.

This can be done via the terminal: `zip -r custom_node.zip custom_node/*`
